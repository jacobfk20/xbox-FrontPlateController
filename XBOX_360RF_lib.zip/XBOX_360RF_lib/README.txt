Built by Jacob Karleskint - MIT License 2016 APR.
Makes it easy to communicate with an Xbox 360 RF daughter board.
Connect any arduino pins to pin 6 & 7 on the 360 RF board.
Declare the pins in the constructor like:
360RF rf = 360RF(pin_clock, pin_data);

Arguments are bytes.

rf.syncController();  <- starts sync process.  This is blocking currently
rf.sendCommand(com[]); <- sends a raw byte array to rf module.
