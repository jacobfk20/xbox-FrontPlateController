#include "RF360.h"


RF360::RF360(byte _clock, byte _data){
	Pin_Data = _data;
	Pin_Clock = _clock;
}




void RF360::sendData(int cmd[]){
  pinMode(Pin_Data, OUTPUT);
  digitalWrite(Pin_Data, LOW);    //start sending data.
  int prev = 1;
  for(int i = 0; i < 10; i++){

    while (prev == digitalRead(Pin_Clock)){} //detects change in clock
    prev = digitalRead(Pin_Clock);
      // should be after downward edge of clock, so send bit of data now
    digitalWrite(Pin_Data, cmd_do[i]);

    while (prev == digitalRead(Pin_Clock)){} //detects upward edge of clock
    prev = digitalRead(Pin_Clock);
  }
  digitalWrite(Pin_Data, HIGH);
  pinMode(Pin_Data, INPUT);
}


void RF360::syncController(){
	int sync_cmd[10] = { 0,0,0,0,0,0,0,1,0,0 };
	sendData(sync_cmd);
}