#include <Arduino.h>

class RF360 {
	public:
	RF360(byte _clock, byte _data);
	void sendData(int cmd[]);
	
	void syncController();



	private:
	byte Pin_Data;
	byte Pin_Clock;

}